void init(void), wait(unsigned), toggle_led(void);

int main(void) {
  init();
  while (1) {
    wait(1000);
    toggle_led();
  }
}

void poll(unsigned char) {}
