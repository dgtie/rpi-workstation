#include <avr/interrupt.h>

void init(void) {
    DDRB = 0x20;            //PB5 = LED
    TCCR0A = 2;             //CTC
    OCR0A = 249;            //1 ms
    TIMSK0 = 2;             //enable TIMER0 COMPA
    TCCR0B = 3;             //prescalar=64, run
    sei();                  //enable interrupt
}

static volatile unsigned char tick;

ISR(TIMER0_COMPA_vect) { ++tick; }

void poll(unsigned char);
void wait(unsigned t) {
    unsigned char c;
    for (poll(c = tick); t--; c = tick) while (c == tick) poll(tick);
}

void toggle_led(void) { PINB = _BV(5); }
