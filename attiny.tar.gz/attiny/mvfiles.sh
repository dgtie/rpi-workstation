#!/usr/bin/env bash

mv iotn414.h /usr/lib/avr/include/avr/
mv crtattiny414.o libattiny414.a libc.a libm.a /usr/lib/gcc/avr/5.4.0/avrxmega3/short-calls/
awk '/#  include <avr\/iotn11.h>/ { print; print "#elif defined (__AVR_ATtiny414__)"; print "#  include <avr/iotn414.h>"; next }1' /usr/lib/avr/include/avr/io.h > io.h
mv io.h /usr/lib/avr/include/avr/

