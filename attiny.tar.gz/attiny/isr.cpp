#include <avr/interrupt.h>

void init(void) {
  PORTA.DIRSET = PIN7_bm;
  TCA0.SINGLE.PER = 1866;
  TCA0.SINGLE.INTCTRL = TCA_SINGLE_OVF_bm;
  TCA0.SINGLE.CTRLA = TCA_SINGLE_ENABLE_bm;
  sei();
}

static volatile unsigned char tick;

ISR(TCA0_OVF_vect) {
  TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
  ++tick; 
}

void poll(unsigned char);
void wait(unsigned t) {
  unsigned char c;
  for (poll(c = tick); t--; c = tick) while (c == tick) poll(tick);
}

void toggle_led(void) { PORTA.OUTTGL = PIN7_bm; }
