#include <avr/interrupt.h>

//void __attribute__((naked, section(".init3"))) init(void) {
void init(void) {
    PORTMUX.CTRLC = PORTMUX_TCA00_bm;    // remap WO0 to PB3
    PORTA.DIRSET = PIN6_bm | PIN5_bm | PIN4_bm | PIN3_bm | PIN2_bm | PIN1_bm;
    PORTB.DIRSET = PIN3_bm | PIN1_bm;
    PORTA.PIN7CTRL = PORT_PULLUPEN_bm;
    PORTB.PIN0CTRL = PORT_PULLUPEN_bm;
    PORTB.PIN2CTRL = PORT_PULLUPEN_bm;
    TCA0.SINGLE.PER = 3333;              // 3.333M / 1K
    TCA0.SINGLE.CMP0 = 1667;
    TCA0.SINGLE.CTRLB = TCA_SINGLE_WGMODE_SINGLESLOPE_gc;
    TCB0.CCMP = 13021;                   // 3.333M / 256 (3.9ms)
    SPI0.CTRLA = SPI_MASTER_bm;
    SPI0.CTRLB = SPI_SSD_bm;             // SS not in use; mode 0
    TCA0.SINGLE.CTRLA = TCA_SINGLE_ENABLE_bm;
    TCB0.CTRLA = TCB_ENABLE_bm;
    TCB0.INTCTRL = TCB_CAPT_bm;
    SLPCTRL.CTRLA = SLPCTRL_SMODE_PDOWN_gc | SLPCTRL_SEN_bm;
    sei();
}

static volatile unsigned char tick;
ISR(TCB0_INT_vect) { TCB0.INTFLAGS = TCB_CAPT_bm; ++tick; }

void poll(unsigned char);
void wait(unsigned t) {
    unsigned char c;
    for (poll(c = tick); t--; c = tick) while (c == tick) poll(tick);
}

ISR(PORTA_PORT_vect) { PORTA.INTFLAGS = PIN7_bm; }
ISR(PORTB_PORT_vect) { PORTB.INTFLAGS = PIN2_bm | PIN0_bm; }
