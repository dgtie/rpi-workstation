#include "button.h"

void init(void), wait(unsigned);
void display_poll(unsigned char);

int main(void) {
  init();
  while (1) wait(0);
}

void poll(unsigned char tick) {
  static unsigned char t;
  if (t == tick) return;
  button::poll(t = tick);
  display_poll(t);
}

