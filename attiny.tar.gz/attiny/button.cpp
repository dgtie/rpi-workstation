#include "button.h"

using namespace button;

class Button {
  PORT_t *base;
  char pin;
public:
  static char keys;
  Button(PORT_t *b, char p): base(b), pin(p) { keys |= p; }
  bool button(void) {
    char k = (base->IN ^ keys) & pin;
    if (k) keys ^= pin;
    return k;
  }
};

static Button left(&PORTB, LEFT);
static Button middle(&PORTB, MIDDLE);
static Button right(&PORTA, RIGHT);

char Button::keys;

void on_left(char), on_middle(char), on_right(char);

namespace button
{
  void poll(unsigned char t) {
    if (t & 7) return;
    if (left.button()) on_left(Button::keys);
    if (middle.button()) on_middle(Button::keys);
    if (right.button()) on_right(Button::keys);
  }
}

void beep_on(void) { TCA0.SINGLE.CTRLB |= TCA_SINGLE_CMP0EN_bm; }
void beep_off(void) { TCA0.SINGLE.CTRLB &= ~TCA_SINGLE_CMP0EN_bm; }
