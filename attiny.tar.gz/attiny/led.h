enum led_state { ON, OFF, NORMAL, FAST, SLOW };

void led(led_state), beep_on(void), beep_off(void);

void button(unsigned char), seven(unsigned char);

void setDisplay(char, char, char, char);