#include <avr/io.h>

namespace button
{
  enum { LEFT=PIN2_bm, MIDDLE=PIN0_bm, RIGHT=PIN7_bm };

  void poll(unsigned char);
}

void beep_on(void), beep_off(void);