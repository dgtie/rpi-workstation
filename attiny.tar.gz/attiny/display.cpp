#include <avr/io.h>
#include <avr/pgmspace.h>
#include "button.h"

class Timer {
  enum { MAX=1535999, SLEEP=7680 };
  enum { STOP, RUN, ALARM } state;
  unsigned long time;
  unsigned sleep_cnt;
  void update(void), sleep(void);
  void alarm_off(void) { beep_off(); if (state == ALARM) stop(); }
public:
  Timer(void){ clear(); }
  void poll(void);
  void add(unsigned u) {
    time += u << 8; if (time > MAX) time = MAX; update(); alarm_off();
  }
  void run(void) { state = RUN; alarm_off(); }
  void stop(void) { state = STOP; alarm_off(); sleep_cnt = SLEEP; }
  void clear(void) { time = 0; update(); stop(); }
} timer;

static char display[4];

static const char digits[] PROGMEM = {            //faed.gcb
  0x0c, 0xfc, 0x8a, 0xa8, 0x78, 0x29, 0x09, 0xbc, 0x08, 0x28, 0xff
};

void display_poll(unsigned char c) {
  timer.poll();
  PORTB.OUTSET = PIN1_bm;
  PORTA.OUTSET = PIN5_bm | PIN4_bm | PIN2_bm;
  SPI0.CTRLA |= SPI_ENABLE_bm;
  SPI0.DATA = display[c &= 3];
  while (!(SPI0.INTFLAGS & SPI_IF_bm));
  SPI0.DATA;
  SPI0.CTRLA &= ~SPI_ENABLE_bm;
  PORTA.OUTCLR = PIN2_bm;
  PORTA.OUTSET = PIN2_bm;
  switch (c) {
    case 0: PORTA.OUTCLR = PIN5_bm; break;
    case 1: PORTA.OUTCLR = PIN4_bm; break;
    case 2: PORTA.OUTCLR = PIN2_bm; break;
    case 3: PORTB.OUTCLR = PIN1_bm;
  }
}

void Timer::poll(void) {
  if (state == STOP) if (!--sleep_cnt) sleep();
  if (state == RUN) {
    if (time) {
      if (!--time) { state = ALARM; beep_on(); }
      else {
        if ((time & 255) == 255) update();
      }
    } else stop();
  }
}

void Timer::update(void) {
  int t = time >> 8;
  int m = t / 60;
  int s = t - m * 60;
  t = s / 10;
  s = s - t * 10;
  display[2] = pgm_read_byte_near(&digits[t]);
  display[3] = pgm_read_byte_near(&digits[s]);
  t = m / 10;
  m = m - t * 10;
  if (t > 9) t = 10;
  display[0] = pgm_read_byte_near(&digits[t]);
  display[1] = pgm_read_byte_near(&digits[m]);
}

void Timer::sleep(void) {
  PORTB.OUTSET = PIN1_bm;
  PORTA.OUTSET = PIN5_bm | PIN4_bm | PIN2_bm;
  PORTA.PIN7CTRL = PORT_PULLUPEN_bm | PORT_ISC_BOTHEDGES_gc;
  PORTB.PIN0CTRL = PORT_PULLUPEN_bm | PORT_ISC_BOTHEDGES_gc;
  PORTB.PIN2CTRL = PORT_PULLUPEN_bm | PORT_ISC_BOTHEDGES_gc;
  asm("sleep");
  PORTA.PIN7CTRL = PORT_PULLUPEN_bm;
  PORTB.PIN0CTRL = PORT_PULLUPEN_bm;
  PORTB.PIN2CTRL = PORT_PULLUPEN_bm; 
}

void on_left(char c) { if (!(c & button::LEFT)) timer.add(60); }
void on_middle(char c) { if (!(c & button::MIDDLE)) timer.run(); }
void on_right(char c) { if (!(c & button::RIGHT)) timer.add(1); }
