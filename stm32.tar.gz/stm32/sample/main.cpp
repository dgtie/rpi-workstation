void wait(unsigned int);   //background jobs are being serviced through this function
void toggle_led(void);

int main(void) {
  while (1) {
    wait(40);
    toggle_led();
  }
}

void poll(unsigned) {}
