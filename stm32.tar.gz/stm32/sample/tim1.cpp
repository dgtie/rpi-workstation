#include <stm32f10x.h>

class Timer {
public:
  Timer(void);
  volatile unsigned tick;
} static timer;

Timer::Timer(void) {
  RCC->APB2ENR = RCC_APB2ENR_TIM1EN | RCC_APB2ENR_IOPCEN;
  GPIOC->CRH = 0x44244444;
  TIM1->DIER = TIM_DIER_UIE;
  TIM1->PSC = 3;                 //18 MHz = 72/(3+1)
  TIM1->ARR = 44999;             //2.5 ms
  NVIC_EnableIRQ(TIM1_UP_IRQn);
  TIM1->CR1 = TIM_CR1_CEN;    		//timer on
}

extern "C" void TIM1_UP_IRQHandler(void) { timer.tick++; }

void poll(unsigned);
void wait(unsigned i) {
  if (!i) return poll(timer.tick);
  i += timer.tick;
  while (i != timer.tick) poll(timer.tick);
}

void toggle_led(void) {
  if (GPIOC->ODR & 0x20) GPIOC->BRR = 0x20; else GPIOC->BSRR = 0x20;
}
